import { faShoppingCart, faPlus, faTrashAlt } from '@fortawesome/free-solid-svg-icons';

export const icons = {
  faShoppingCart,
  faPlus,
  faTrashAlt
};