import { EmPromocaoPipe } from './em-promocao-pipe';

describe('EmPromocaoPipe', () => {
  it('create an instance', () => {
    const pipe = new EmPromocaoPipe();
    expect(pipe).toBeTruthy();
  });
});
